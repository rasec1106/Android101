package pe.edu.cibertec.ct01_herreravillacorta_cesarhumberto.model

class PizzaSize (
    val size: String,
    val price: Int
        )